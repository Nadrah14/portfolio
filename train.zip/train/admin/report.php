<?php include"includes/admin_header.php"; ?>

<?php include"includes/admin_navigation.php"; ?>

    <script src = "js/jquery.js"></script>
	<script src = "js/bootstrap.js"></script>
    
    <script type = "text/javascript">
		$(document).ready(function(){
			$('.rorder_id').click(function(){
				$order_id = $(this).attr('name');
				$('.remove_id').click(function(){
					window.location = 'delete_time.php?order_id=' + $order_id;
				});
			});
		});
	</script>

    <script type="text/javascript" src="DataTables/datatables.min.js">
        $(document).ready(function() {
            $('#myTable-trans').DataTable();
        });
    </script>

<html lang = "eng">
    
    <div id="wrapper">
        


        <div id="page-wrapper">
            <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome To Admin
                            <small><?php echo ucfirst($_SESSION['s_username']);   ?></small>
                        </h1>
                    </div>
            </div>
            
            
<head>
	<style>
	.title2 {
	font-size:18px;
	}
	</style>
	</head>
	<body>
		<div class = "container-fluid" style = "margin-top:0px;">
			<div class = "alert alert-info title2">OVERALL REPORT</div>
			<div class = "modal fade" id = "delete" role = "dialog" aria-labelledby = "myModallabel">
				<div class = "modal-dialog" role = "document">
					<div class = "modal-content ">
						<div class = "modal-body" >
							<center><label class = "text-danger">Are you sure you want to delete this record?</label></center>
							<br />

							<center><a class = "btn btn-danger remove_id"><span class = "glyphicon glyphicon-trash"></span> Yes</a></form> <button type = "button" class = "btn btn-warning" data-dismiss = "modal" aria-label = "No"><span class = "glyphicon glyphicon-remove"></span> No</button></center>
							
						</div>
					</div>
				</div>
			</div>
			<div class = "modal fade" id = "delete2" tabindex = "-1" role = "dialog" aria-labelledby = "myModallabel">
				<div class = "modal-dialog" role = "document">
					<div class = "modal-content ">
						<div class = "modal-body" >
							<center><label class = "text-danger">Are you sure you want to delete this record?</label></center>
							<br />
							<center><a class = "btn btn-danger remove_id2" href="delete_timeall.php"><span class = "glyphicon glyphicon-trash"></span> Yes</a> <button type = "button" class = "btn btn-warning" data-dismiss = "modal" aria-label = "No"><span class = "glyphicon glyphicon-remove"></span> No</button></center>
						</div>
					</div>
				</div>
			</div>
			<div class = "well col-lg-12" style= "color: black;">
				<table id = "myTable-trans" class = "table table-bordered">
					<thead class = "alert-info">
						<tr>
							<th>Order ID</th>
							<th>User ID</th>
							<th>Username</th>
							<th>Ic number</th>
							<th>Passport</th>
							<th>Email</th>
                            <th>Station</th>
                            <th>Destination</th>
                            <th>Date</th>
                            <th>Cost</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody style= "color: black;">
<?php
                        $conn = mysqli_connect("localhost",'root','','train');
						$q_time = $conn->query("SELECT * FROM `orders`") or die(mysqli_error());
						while($f_time = $q_time->fetch_array()){
							
?>
						<tr style= "color: black;">
							<td><?php echo $f_time['order_id'] ?></td>
                            <td><?php echo $f_time['user_id'] ?></td>
                            <td><?php echo $f_time['user_name'] ?></td>
                            <td><?php echo $f_time['ic_no'] ?></td>
                            <td><?php echo $f_time['passport'] ?></td>
                            <td><?php echo $f_time['email'] ?></td>
                            <td><?php echo $f_time['source'] ?></td>
                            <td><?php echo $f_time['destination'] ?></td>
                            <td><?php echo $f_time['date'] ?></td>
                            <td><?php echo $f_time['cost'] ?></td>
							<td><button name = "<?php echo $f_time['order_id']?>" class = "btn btn-danger rorder_id" href = "#" data-toggle = "modal" data-target = "#delete"><span class = "glyphicon glyphicon-remove"></span></button></td>
						</tr>
<?php
						}
             
?>
					</tbody>
					</table>
					<div><button style="float: right;" class = "btn btn-danger delall" href = "#" data-toggle = "modal" data-target = "#delete2">Delete All <span class = "glyphicon glyphicon-remove-sign"></span></button>
                </div>
            </div>
        </div>
     </div>
	</body>
            
            
            

</html>

<?php include"includes/admin_footer.php"; ?>