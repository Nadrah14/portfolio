<?php
	require("db.php");
	$connection->query("Delete FROM `orders` ") or die(mysqli_error());
	header('location: report.php');