<?php
	require("db.php");
	$connection->query("DELETE FROM `orders` WHERE `order_id` = '$_REQUEST[order_id]'") or die(mysqli_error());
	header('location: report.php');