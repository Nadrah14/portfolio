<?php include "db.php"; ?>
<?php include "header.php"; ?>
    
    <!-- Navigation -->
    <?php include "navigation.php"; ?>

    <!-- Page Content -->
    <!-- <div class="container jumbotron" style="width: 45%; border-radius: 15px"> -->

    <?php

    	if (isset($_GET['orderid'])) {
    		$orderid_cancel = $_GET['orderid'];

    		$query = "DELETE FROM orders WHERE order_id=$orderid_cancel";

    		$cancel_order = mysqli_query($connection,$query);

    		if (!$cancel_order) {
    			die("Query Failed".mysqli_error($connection));
    		}
    	}

    ?>

    <div class="container" style="width: 50%;">
        
    	<p><h3>Your ticket stands Cancelled as per your Request</h3></p>
    	<br>
    	<p><h3>Hope To See You Soon!!</h3></p>

    </div>
        <hr>


<?php include "footer.php"; ?> 