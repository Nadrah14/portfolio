   <!-- Footer -->
    </div>
        <footer id="myFooter"  class="fixed-bottom" >
        <div class="container">
            <div class="row">
            </div>
        </div>
        <div class="social-networks">
            <a href="https://twitter.com" class="twitter"><i class="fa fa-twitter"></i></a>
            <a href="https://www.facebook.com" class="facebook"><i class="fa fa-facebook"></i></a>
            <a href="https://google.com" class="google"><i class="fa fa-google-plus"></i></a>
        </div>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    
    <!-- /.container -->

    <!-- jQuery -->
    <!-- <script src="js/jquery.js"></script> -->

    <!-- Bootstrap Core JavaScript -->
   <!--  <script src="js/bootstrap.min.js"></script> -->

</body>

</html>
