<?php include "includes/db.php"; ?>
<?php include "includes/header.php"; ?>
    
    <!-- Navigation -->
    <?php include "includes/navigation.php";
     use PHPMailer\PHPMailer\PHPMailer;
     use PHPMailer\PHPMailer\SMTP;
     use PHPMailer\PHPMailer\Exception;
     include 'PHPMailer/src/Exception.php';
     include 'PHPMailer/src/PHPMailer.php';
     include 'PHPMailer/src/SMTP.php'; ?>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
                
              <?php

                    if (isset($_SESSION['s_id'])) {
                            

                        ?>


                        <div class="jumbotron">
                            <div class="container-fluid">
                                <h2>Enter Details:</h2>

                                <form action="" method="get" class="form-horizontal">
                                
                                    <label>Tickt Count:</label>
                                    <select name="count" style="margin-bottom: 15px;margin-top: 15px;" class="form-control">
                                        <option value="0">Ticket Count</option>
                                        <?php
                                            for ($i=1; $i <= 100; $i++) { ?>
                                                <option value="<?php echo $i ?>"><?php echo $i ?></option> <?php
                                            }

                                        ?>
                                    </select>
                                    <button class="btn-xs btn-primary" style="margin-left: 5px;">GO</button>

                                </form>

                                <form action="customer_info.php?count=<?php echo ($_REQUEST['count'])?>" method="post" class="form-horizontal">
                                
                                <?php
                                if (isset($_REQUEST['count'])) {
                                    $count = $_REQUEST['count'];
                                    //$nilai1 = $_POST['student'];
                                   // $nilai2 = $_POST['oku'];
                                    //$nilai3 = $_POST['senior'];
                                    //$nilai4 = $_POST['normal'];
                                    
                                
                                   // $_SESSION['nostudent'] = $_POST['student'];
                                   // $_SESSION['nooku'] = $_POST['oku'];
                                   // $_SESSION['nosenior'] = $_POST['senior'];
                                   // $_SESSION['nonormal'] = $_POST['normal'];
                                    
                                    //echo "<h1>$count</h1>";

                                    for ($i=0; $i < $count; $i++) { 

                                        ?>
                                        <h3><?php echo "Passenger "; echo $i+1;?></h3>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2">Name:</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="name" placeholder="Name" name="name<?php echo "$i" ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2">Ic Number:</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="icno" placeholder="Ic Number" name="ic<?php echo "$i" ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2">Passport Number:</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="pport" placeholder="Passport" name="pport<?php echo "$i" ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" >Email:</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="email" placeholder="email" name="email<?php echo "$i" ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2">Ticket Type:</label>
                                            <div class="col-sm-10">
                                            <select class="form-control" id="type" placeholder="type" name="type<?php echo "$i" ?>">
                                                <option value="normal">......</option>
                                                <option value="oku">Oku</option>
                                                <option value="nomal">Normal</option>
                                                <option value="student">Student</option>
                                                <option value="senior">Senior</option>
                                            </select>
                                            </div>
                                        </div>
                                        <?php
                                    }

                                }

                                ?>

                                <button class="btn btn-primary" name="booking" onclick="window.open('http://localhost/train/Thank.php')" style="margin-left: 40%; margin-top: 15px;">Book Tickets</button>

                                </form>

                                <?php

                                if (isset($_POST['booking'])) {
                                    //echo "<h1>hello</h1>";
                                    if (isset($_GET['count'])) {
                                        $count = $_GET['count'];
                                    }
                                    $charge = $_SESSION['charge'];
                                    $discount = $_SESSION['discount'];
                                    $discountoku = $_SESSION['discountoku'];
                                    $discountstudent = $_SESSION['discountstudent'];
                                    $discountsenior = $_SESSION['discountsenior'];
                                    $destination = $_SESSION['destination'];
                                    $source= $_SESSION['station'];
                                    $tickettype = $_SESSION['tickettype'];
                                    
                                    
                                    
                                    if ($tickettype =="two-way"){
                                        $discount2 = $discount * 2;
                                        $discountoku2 = $discountoku * 2;
                                        $discountstudent2 = $discountstudent * 2;
                                        $discountsenior2 = $discountsenior * 2;
                                    }
                                    else
                                    {
                                        $discount2 = $discount * 1;
                                        $discountoku2 = $discountoku * 1;
                                        $discountstudent2 = $discountstudent * 1;
                                        $discountsenior2 = $discountsenior * 1;
                                    }
                                    
                                    $totalcost = number_format($discount2 + $discountoku2 + $discountstudent2 + $discountsenior2,2);

                                    //echo $cost;

                                    // $query = "INSERT INTO orders(user_id, user_name, ic_no, passport, email, usertype, source, destination,date,cost) VALUES($_SESSION['s_username'],$source,$destination,now())";

                                    $arr = array();
                                    $arr1 = array();
                                    $arr2 = array();
                                    $arr3 = array();
                                    $arr4 = array();
                                    for ($i=0; $i < $count; $i++) {
                                        //echo "<h1>hello</h1>";
                                        $name_query = 'name'.$i ;
                                        $ic_query = 'ic'.$i ;
                                        $pport_query = 'pport'.$i ;
                                        $email_query = 'email'.$i ;
                                        $type_query = 'type'.$i ;
                                        //echo $what;
                                        array_push($arr,$_POST[$name_query]);
                                        array_push($arr1,$_POST[$ic_query]);
                                        array_push($arr2,$_POST[$pport_query]);
                                        array_push($arr3,$_POST[$email_query]);
                                        array_push($arr4,$_POST[$type_query]);
                                    }

                                    
                                    for ($i=0; $i < $count; $i++) { 
                                        
                                        $curr_name = $arr[$i];
                                        $curr_ic = $arr1[$i];
                                        $curr_pport = $arr2[$i];
                                        $curr_email = $arr3[$i];
                                        $curr_type = $arr4[$i];
                                        $user_id = $_SESSION['s_id'];
                                        
                                        if($arr4[$i] == "oku"){
                                            $price = $discountoku2;
                                        }
                                        elseif($arr4[$i] == "student"){
                                            $price = $discountstudent2;
                                        }
                                        elseif($arr4[$i] == "senior"){
                                            $price = $discountsenior2;
                                        }
                                        else
                                        {
                                           $price = $discount2;
                                        }
                                        
                                        

                                        $query = "INSERT INTO orders(user_id, user_name, ic_no, passport, email, type, status, source, destination,date,cost) VALUES($user_id , '$curr_name', '$curr_ic', '$curr_pport', '$curr_email', '$tickettype','$curr_type', '$source', '$destination', now(),$price)";

                                        $booking_query = mysqli_query($connection,$query);
                                        if (!$booking_query) {
                                            die("Query Failed" . mysqli_error($connection));
                                        }
                                    }
                                            $curr_user_id = $_SESSION['s_id'];
                                            $query = "SELECT * FROM orders WHERE user_id = $curr_user_id AND date = NOW()";
                                            $select_user_orders = mysqli_query($connection, $query);
                                  
                                            while ($row = mysqli_fetch_assoc($select_user_orders)) {
                                              $passenger = $row['user_name'];
                                              $source = $row['source'];
                                              $destination = $row['destination'];
                                              $dob = $row['date'];
                                              $type = $row['type'];
                                              $type2 = $row['status'];
                                              $cost = $row['cost'];
                                              $orderid = $row['order_id'];
                                              $traindate = $row['date'];
                                              
                                        //include 'mail_password.inc';
                                        // Instantiation and passing `true` enables exceptions
                                        $mail = new PHPMailer(true);
                                        try {
                                            //Server settings
                                            $mail->isSMTP();
                                            $mail->Host       = 'smtp.gmail.com';
                                            $mail->SMTPAuth   = true;
                                            $mail->Username   = 'littlecattinny@gmail.com';
                                            $mail->Password   = 'Tinny1408';
                                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                                            $mail->Port       = 587;
                                            
                                 
                                            $sendto = $_SESSION['email'];
                                            $subject = "KTM Ticket Information";
                                            $message = '<table>
                                                        <tbody>
                                                          <tr>
                                                            <td><b>Passenger Name:</b> </td>
                                                            <td>'.$passenger.'</td>
                                                          </tr>
                                                          <tr>
                                                            <td><b>Source: </b></td>
                                                            <td>'.ucfirst($source).'</td>
                                                          </tr>
                                                          <tr>
                                                            <td><b>Destination: </b></td>
                                                            <td>'.ucfirst($destination).'</td>
                                                          </tr>
                                                          <tr>
                                                            <td><b>Date Of Booking: </b></td>
                                                            <td>'.$dob.'</td>
                                                          </tr>
                                                          <tr>
                                                            <td><b>Travelling Date: </b></td>
                                                            <td>'.$traindate.'</td>
                                                          </tr>
                                                          <tr>
                                                            <td><b>Ticket Type<b></td>
                                                            <td>'.$type.'</td>
                                                          </tr>
                                                          <tr>
                                                            <td><b>Status<b></td>
                                                            <td>'.$type2.'</td>
                                                          </tr>
                                                          <tr>
                                                            <td><b> Total Cost:</b></td>
                                                            <td><b>RM </b>'.$cost.'</td>
                                                          </tr>
                                                          <br><br><br>
                                                        </tbody>
                                                      </table>';
                                            //Recipients
                                            $mail->setFrom('littlecattinny@gmail.com', 'Tinny');
                                            // send to one recepient only, name is optional 2nd argument
                                            $mail->addAddress($sendto);
                                            $mail->addReplyTo('nadrahhmzh1997@gmail.com', 'Nadrah'); 

                                                $mail->isHTML(true);                         
                                                $mail->Subject = $subject;
                                                $mail->Body    = $message;
                                                $mail->AltBody = $message;
                                                $mail->send();
                                                } catch (Exception $e) {
                                                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                                                    } 
                                                                    
                                            }
                                }

                                ?>
                            </div>
                        </div>

                        <hr>
                    <?php } ?>
            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include "includes/sidebar.php"; ?>

        </div>
        <!-- /.row -->

        <hr>

<?php include "includes/footer.php"; ?>