
<?php include "includes/header.php"; ?>
<?php include "includes/navigation.php"; ?>
<html>
    <head>
        <title></title>
    </head>
        <body>
            <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
        <div class="col-md-8">
        <div id="Tickets Booked">
          <div class="panel panel-default" >
          <div class="panel-heading" style="background-color: #182c39; color: white;">
          <h3>KTM tickets</h3>
          </div>
          <br>


          <h3 style="margin-bottom: -40px"><b>Current tickets:</b></h3>
          <br>
          <?php include "includes/db.php"; ?>
          <?php
          $curr_user_id = $_SESSION['s_id'];

          $query = "SELECT * FROM orders WHERE user_id = $curr_user_id";
          $select_user_orders = mysqli_query($connection, $query);

          while ($row = mysqli_fetch_assoc($select_user_orders)) {
            $passenger = $row['user_name'];
            $source = $row['source'];
            $destination = $row['destination'];
            $dob = $row['date'];
            $type = $row['type'];
            $type2 = $row['status'];
            $cost = $row['cost'];
            $orderid = $row['order_id'];
            $traindate = $row['date'];
            
            //echo $traindate;
            if (date("Y-m-d") <= $traindate) {
            ?>
            <table class="table table-striped" style="width: 50%;">
              <tbody>
                <tr>
                  <td><b>Passenger Name:</b> </td>
                  <td><?php echo $passenger; ?></td>
                </tr>
                <tr>
                  <td><b>Source: </b></td>
                  <td><?php echo ucfirst($source); ?></td>
                </tr>
                <tr>
                  <td><b>Destination: </b></td>
                  <td><?php echo ucfirst($destination); ?></td>
                </tr>
                <tr>
                  <td><b>Date And time Of Booking: </b></td>
                  <td><?php echo $dob; ?></td>
                </tr>
                <tr>
                  <td><b>Travelling Date And Time: </b></td>
                  <td><?php echo $traindate; ?></td>
                </tr>
                <tr>
                  <td><b>Ticket Type<b></td>
                  <td><?php echo $type; ?></td>
                </tr>
                <tr>
                  <td><b>Status<b></td>
                  <td><?php echo $type2; ?></td>
                </tr>
                <tr>
                  <td><b> Total Cost:</b></td>
                  <td><b>RM </b><?php echo $cost; ?></td>
                </tr>
                <tr>
                  <td><b>Print Receipt<b></td>
                  <td><a href=" receipt.php?orderid=<?php echo $orderid ?>">Receipt</a></td>
                </tr>
                <tr>
                  <td><b>Cancel Ticket<b></td>
                  <td>
                    <form action="includes/cancel.php?orderid=<?php echo $orderid ?>" method="post">
                      <button class="btn btn-primary btn-xs" name="cancel">Cancel</button></td>
                    </form>
                </tr>
                <br><br><br>
              </tbody>
            </table>

          <?php } } ?>
        
        <h3 style="margin-bottom: -40px"><b>Past tickets:</b></h3>
        <br>
          <?php

          $query = "SELECT * FROM orders WHERE user_id = $curr_user_id";

          $select_user_orders = mysqli_query($connection, $query);

          while ($row = mysqli_fetch_assoc($select_user_orders)) {
            $passenger = $row['user_name'];
            $source = $row['source'];
            $destination = $row['destination'];
            $dob = $row['date'];
            $cost = $row['cost'];
            $orderid = $row['order_id'];
            $busdate = $row['date'];
            
            //echo $busdate;
            if (date("Y-m-d") > $busdate) {
            ?>
            <br>
            <table class="table table-striped" style="width: 50%">
              <tbody>
                <tr>
                  <td><b>Passenger Name:</b> </td>
                  <td><?php echo $passenger; ?></td>
                </tr>
                <tr>
                  <td><b>Source: </b></td>
                  <td><?php echo ucfirst($source); ?></td>
                </tr>
                <tr>
                  <td><b>Destination: </b></td>
                  <td><?php echo ucfirst($destination); ?></td>
                </tr>
                <tr>
                  <td><b>Date Of Booking: </b></td>
                  <td><?php echo $dob; ?></td>
                </tr>
                <tr>
                  <td><b>Travelling Date: </b></td>
                  <td><?php echo $busdate; ?></td>
                </tr>
                <tr>
                  <td><b>Print Receipt<b></td>
                  <td><a href="receipt.php?orderid=<?php echo $orderid ?>">Receipt</a></td>
                </tr>
                <br><br><br>
              </tbody>
            </table>

          <?php } } ?>

        </div></div></div></div></div>
       </body> 
</html>
<?php include "includes/footer.php"; ?> 