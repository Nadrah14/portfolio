<?php include "includes/db.php"; ?>
<?php include "includes/header.php"; ?>
    
    <!-- Navigation -->
    <?php include "includes/navigation.php"; ?>

    <!-- Page Content -->
    <!-- <div class="container jumbotron" style="width: 45%; border-radius: 15px"> -->

    <div class="container" style="width: 50%;">
                
      <h2>Account Details:</h2>
      <table class="table table-striped" style="width: 100%">
              <tbody>
                <tr>
                  <td><b>Photo:</b> </td>
                  <td><img src="admin/images/<?php echo $_SESSION['s_image']; ?>" width=50></td>
                </tr>
                <tr>
                  <td><b>UserID:</b> </td>
                  <td><?php echo ucfirst($_SESSION['s_id']); ?></td>
                </tr>
                <tr>
                  <td><b>Account Holder's Name:</b> </td>
                  <td><?php echo ucfirst($_SESSION['s_username']); ?></td>
                </tr>
                <tr>
                  <td><b>FirstName:</b> </td>
                  <td><?php echo ucfirst($_SESSION['s_firstname']); ?></td>
                </tr>
                <tr>
                  <td><b>LastName:</b> </td>
                  <td><?php echo ucfirst($_SESSION['s_lastname']); ?></td>
                </tr>

                <br>
              </tbody>
            </table>
<br>

      <?php
        if (isset($_GET['orderid'])) {
          $input_order_id = $_GET['orderid'];
          //echo $input_order_id;
        }

        $query = "SELECT * FROM orders WHERE order_id=$input_order_id";

        $select_order = mysqli_query($connection,$query);

        while ($row = mysqli_fetch_assoc($select_order)) {
            $passenger = $row['user_name'];
            $source = $row['source'];
            $destination = $row['destination'];
            $dob = $row['date'];
            $orderid = $row['order_id'];
            $type = $row['type'];
            $price = $row['cost'];
            $status = $row['status'];

            ?>

            <h2>Passenger Details:-</h2>

            <table class="table table-striped" style="width: 100%">
              <tbody>
                <tr>
                  <td><b>Passenger Name:</b> </td>
                  <td><?php echo $passenger; ?></td>
                </tr>
                <tr>
                  <td><b>Source: </b></td>
                  <td><?php echo ucfirst($source); ?></td>
                </tr>
                <tr>
                  <td><b>Destination: </b></td>
                  <td><?php echo ucfirst($destination); ?></td>
                </tr>
                <tr>
                  <td><b>Date Of Booking: </b></td>
                  <td><?php echo $dob; ?></td>
                </tr>
                <tr>
                  <td><b>Ticket Type: </b></td>
                  <td><?php echo $type; ?></td>
                </tr>
                 <tr>
                  <td><b>Status: </b></td>
                  <td><?php echo $status; ?></td>
                </tr>
                <tr>
                  <td><b>Price: </b></td>
                  <td><?php echo $price; ?></td>
                </tr>
                <br>
              </tbody>
            </table>

          <?php } ?>                 

    </div>
        <hr>


    <script>
    function openCity(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
    }
    </script>

<?php include "includes/footer.php"; ?> 