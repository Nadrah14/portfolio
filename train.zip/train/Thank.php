<?php include "includes/db.php"; ?>
<?php include "includes/header.php"; ?>

<?php include "includes/navigation.php"; ?>


<div class="container">
<div class="row">
    <form>
<?php
echo "<p><b>Thank you for purchasing a ticket</b></p>"

?>
<button class="btn btn-primary" name="My Booking" onclick="window.open('http://localhost/train/mybooking.php');" style="margin-left: 40%; margin-top: 15px;">My Booking</button>

</form>
</div>
</div>














<?php include "includes/footer.php"; ?>