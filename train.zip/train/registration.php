<?php include "includes/db.php"; ?>
<?php include "includes/header.php"; ?>
    
    <!-- Navigation -->
    <?php include "includes/navigation.php"; ?>

<?php

$UsernameErr = ""; $FirstnameErr = ""; $LastnameErr = ""; $emailErr = ""; $phone_noErr = ""; $passwordErr = ""; $ICErr = ""; $PportErr = "";
$Username = ""; $Firstname = ""; $Lastname = ""; $email = ""; $phone_no = ""; $password = ""; $IC = ""; $Pport = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["username"])) {
    $UsernameErr = "Username is required";
  } else {
    $Username = ($_POST["username"]);
  }

  if (empty($_POST["firstname"])) {
    $FirstnameErr = "First name is required";
  } else {
    $Firstname = ($_POST["firstname"]);
  }

  if (empty($_POST["lastname"])) {
    $LastnameErr = "Last name is required";
  } else {
    $Lastname = ($_POST["lastname"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = ($_POST["email"]);
  }
  
  if( (empty($_POST["ic_no"])) && (empty($_POST["p_port"]))) {
    $ICErr = "IC number or passport number is required";
    $PportErr = "IC number or passport number is required";
  } elseif( ($_POST["ic_no"]) && (empty($_POST["p_port"])))  {
    $IC = ($_POST["ic_no"]);
  } elseif( (empty($_POST["ic_no"]) && ($_POST["p_port"]))) {
    $Pport = ($_POST["p_port"]);
  } else {
    $IC = ($_POST["ic_no"]);
    $Pport = ($_POST["p_port"]);
  }

  if (empty($_POST["phone_no"])) {
    $phone_noErr = "Phone number is required";
  } else {
    $phone_no = ($_POST["phone_no"]);
  }
  
  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = ($_POST["password"]);
  }
}
?>

<?php

if (isset($_POST['register'])) {
//echo "registered";
    $username = $_POST['username'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $phone_no = $_POST['phone_no'];
    $password = $_POST['password'];
    $ic_no = $_POST['ic_no'];
    $passport= $_POST['p_port'];

    $image = $_FILES['image']['name'];
    $tmp_image = $_FILES['image']['tmp_name'];

    move_uploaded_file($tmp_image, "images/$image");
    if ($image == "") {
      $image = "user_default.jpg";
    }

if ($username=="" || $firstname=="" || $lastname=="" || $email=="" || $phone_no=="" || $image=="" || $password=="") {
  # code...
  echo "**ALL FIELDS MANDATORY EXCEPT PASSPORT NO IF YOU HAVE IC NUMBER OR VICE VERSA";
}


elseif (strlen($phone_no)!=11) {
  # code...
  echo "**PhoneNo Must Contain Of 11 bits";
}

else {

$query = "INSERT INTO users(username, user_password, user_firstname, user_lastname, user_email, user_phoneno, user_role, user_image, ic_no, passport) VALUES('$username', '$password', '$firstname', '$lastname', '$email', '$phone_no', 'subscriber', '$image' , '$ic_no', '$passport') ";

$register_user = mysqli_query($connection, $query);

if(!$register_user) {
    die("Query Failed" . mysqli_error($connection));
}

header("Location: index.php");

}

}
 
?>



    <!-- Page Content -->
    <!-- <div class="container jumbotron" style="width: 45%; border-radius: 15px"> -->

    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <img src="images/train.jpeg" style="margin-top: 60%;">
            </div>
            <div class="col-lg-6">
                
              
              <h2 style="margin-left: 40%;">Registration</h2>
              <form name="register" action="" method="post" enctype="multipart/form-data">
                
                <div class="form-group">
                  <label>Username:</label>
                  <input type="text" class="form-control" placeholder="Enter Username" name="username">
                  <span class="error">* <?php echo $UsernameErr;?></span>
                </div>

                <div class="form-group">
                  <label>Firstname:</label>
                  <input type="text" class="form-control" placeholder="Enter Firstname" name="firstname">
                  <span class="error">* <?php echo $FirstnameErr;?></span>
                </div>

                <div class="form-group">
                  <label>Lastname:</label>
                  <input type="text" class="form-control" placeholder="Enter Lastname" name="lastname">
                  <span class="error">* <?php echo $LastnameErr;?></span>
                </div>
                
                <div class="form-group">
                  <label>IC No:</label>
                  <input type="input" class="form-control" placeholder="Enter IC number If You Have IC" name="ic_no">
                  <span class="error">* <?php echo $ICErr;?></span>
                </div>
                
                <div class="form-group">
                  <label>Passport No:</label>
                  <input type="input" class="form-control" placeholder="ONLY Enter Passport Number If You Dont have IC Number" name="p_port">
                  <span class="error">* <?php echo $PportErr;?></span>
                </div>
                
                <div class="form-group">
                    <label>UserImage</label>
                    <input type="file" name="image" >
                </div>

                <div class="form-group">
                  <label>Email:</label>
                  <input type="email" class="form-control" placeholder="Enter email" name="email">
                  <span class="error">* <?php echo $emailErr;?></span>
                </div>
                
                <div class="form-group">
                  <label>Phone No:</label>
                  <input type="text" class="form-control" placeholder="Enter Phone Number" name="phone_no">
                  <span class="error">* <?php echo $phone_noErr;?></span>
                </div>


                <div class="form-group">
                  <label>Password:</label>
                  <input type="password" class="form-control"  placeholder="Enter password" name="password">
                  <span class="error">* <?php echo $passwordErr;?></span>
                </div>
        
                <button type="submit" class="btn btn-primary" name="register" style="margin-left: 45%; margin-top: 20px;">Register</button>
              </form>
              
            

            </div>
        </div>

    </div>
        <hr>

<?php include "includes/footer.php"; ?>