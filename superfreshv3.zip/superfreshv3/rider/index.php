<?php 
include '../controller/controller.php';

if(!isset($_SESSION['user_id'])){
    echo "<script>window.location = '../login.php'</script>";
}

$control = new controller;
$conn = $control->open();

$user = $control->getAuth($conn);
// $listBirthday = $control->listBirthday($conn);

// $getEvent = $control->getListTableName($conn, 'events', ' date >= DATE(NOW())');
// $getAgm = $control->getListTableName($conn, 'agm');


// $totalEvent = $control->getCount($conn, 'events');
// $totalJoinedEvent = $control->getCount($conn, 'records', 'WHERE status = ' . $control::STATUS_RQT_ACCEPT . ' AND user_id = ' . $user['id']);
// $totalPendingEvent = $control->getCount($conn, 'records', 'WHERE status = ' . $control::STATUS_RQT_PENDING . ' AND user_id = ' . $user['id']);
// $totalRejectEvent = $control->getCount($conn, 'records', 'WHERE status = ' . $control::STATUS_RQT_REJECT . ' AND user_id = ' . $user['id']);

?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'c_head.php'; ?>
    <body>

        <!-- Begin page -->
        <div id="wrapper">

            
        <?php include 'c_topbar.php'; ?>

            
            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'c_sidebar.php'; ?>

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-layers float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Total Order</h6>
                                    <h3 class="my-3" data-plugin="counterup"><?php echo $totalEvent['total']; ?></h3>
                                    <span class="badge badge-success mr-1"> -
                                </div>
                            </div>

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-chart float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Order Pending</h6>
                                    <h3 class="my-3"><span data-plugin="counterup"><?php echo $totalPendingEvent['total'] ?></span></h3>
                                    <span class="badge badge-pink mr-1">-
                                </div>
                            </div>

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-paypal float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Order Out Of Delivery</h6>
                                    <h3 class="my-3"><span data-plugin="counterup"><?php echo $totalJoinedEvent['total'] ?></span></h3>
                                    <span class="badge badge-danger mr-1"> -
                                </div>
                            </div>

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-rocket float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Order Completed</h6>
                                    <h3 class="my-3" data-plugin="counterup"><?php echo $totalRejectEvent['total'] ?></h3>
                                    <span class="badge badge-warning mr-1"> -
                                </div>
                            </div>
                        </div>
                        <!-- end row -->


                        <div class="row">
                        <div class="col-xl-12">
                                <div class="card-box">

                                    <h4 class="header-title mb-3">New Order</h4>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-nowrap mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Image</th>
                                                    <th>Title</th>
                                                    <th>Location</th>
                                                    <th>Date | Time</th>
                                                    <th>Amount</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php if($getEvent != null) {
                                                foreach($getEvent as $event){  
                                                    $checkIfRequest = $control->getTableByCustomWhere($conn, 'records', ' event_id = '. $event['id']);
                                                    ?>
                                                <tr>
                                                    <td align="center" ><img src="../images/<?php echo $event['image'] ?>" width="100"></td>
                                                    <td ><?php echo $event['title'] ?></td>
                                                    <td ><?php echo $event['location'] ?></td>
                                                    <td ><?php echo $event['date'] . ' | ' . $event['time'] ?></td>
                                                    <td >RM<?php echo $event['amount'] ?></td>
                                                    <td>
                                                        <?php
                                                        if($checkIfRequest != null){
                                                            if($checkIfRequest['status'] == $control::STATUS_RQT_PENDING){ ?>
                                                                <span class="badge badge-warning">Pending</span>
                                                            <?php } else if ($checkIfRequest['status'] == $control::STATUS_RQT_REJECT){ ?>
                                                                <span class="badge badge-danger">Rejected</span>
                                                            <?php } else if ($checkIfRequest['status'] == $control::STATUS_RQT_ACCEPT){ ?>
                                                                <span class="badge badge-success">Accepted</span>
                                                            <?php } } else { ?>
                                                        <a class="btn btn-sm btn-success" href="joinevent.php?id=<?php echo $event['id'] ?>">Request To Join</a>
                                                        <?php } ?>
                                                    </td>
                                                </tr>
                                            <?php } } else { ?>
                                                <tr>
                                                    <td colspan="6">No Event Found</td>
                                                </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div><!-- end col-->
                            </div>
                            <!-- end row -->
                            <div class="row">
                                <div class="col-md-12">
                                        <div class="card-box">
                                            <h4 class="header-title mb-3">In Progress Order</h4>

                                            <div class="table-responsive">
                                        <table class="table table-bordered table-nowrap mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php if($getAgm != null) {
                                                foreach($getAgm as $agm){ ?>
                                                <tr>
                                                    <td><?php echo $agm['title'] ?></td>
                                                    <td><?php echo $agm['description'] ?></td>
                                                    <td>
                                                        <a href="../images/<?php echo $agm['document'] ?>" download="<?php echo $agm['document'] ?>" class="btn btn-sm btn-info">Download</a>
                                                        <a href="../controller/controller.php?mod=deleteAgm&id=<?php echo $agm['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
                                                    </td>
                                                </tr>
                                            <?php } } else { ?>
                                                <tr>
                                                    <td colspan="5">No Agm Notice Found</td>
                                                </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>

                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="card-box">
                                            <h4 class="header-title mb-3">Complete Order</h4>

                                            <div class="table-responsive">
                                        <table class="table table-bordered table-nowrap mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php if($getAgm != null) {
                                                foreach($getAgm as $agm){ ?>
                                                <tr>
                                                    <td><?php echo $agm['title'] ?></td>
                                                    <td><?php echo $agm['description'] ?></td>
                                                    <td>
                                                        <a href="../images/<?php echo $agm['document'] ?>" download="<?php echo $agm['document'] ?>" class="btn btn-sm btn-info">Download</a>
                                                        <a href="../controller/controller.php?mod=deleteAgm&id=<?php echo $agm['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
                                                    </td>
                                                </tr>
                                            <?php } } else { ?>
                                                <tr>
                                                    <td colspan="5">No Agm Notice Found</td>
                                                </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>

                                        </div>
                                    </div>
                            </div>
                        
                    </div> <!-- end container-fluid -->

                </div> <!-- end content -->

                

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2016 - 2019 &copy; Uplon theme by <a href="">Coderthemes</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!--Morris Chart-->
        <script src="assets/libs/morris-js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>

        <!-- Dashboard init js-->
        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>
        
    </body>
</html>