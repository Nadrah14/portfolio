<?php 
include '../controller/controller.php';

if(!isset($_SESSION['user_id'])){
    echo "<script>window.location = '../login.php'</script>";
}

$control = new controller;
$conn = $control->open();

$user = $control->getAuth($conn);
$getEvent = $control->getListTableName($conn, 'events', ' events.date <= DATE(NOW()) ', '', 'LEFT JOIN records ON (events.id = records.event_id)');
$getEventRejected = $control->getListTableName($conn, 'events', ' status = ' . $control::STATUS_RQT_REJECT);

?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'c_head.php'; ?>
    <!-- Table datatable css -->
    <link href="assets/libs/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        
        <link href="assets/libs/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/select.bootstrap4.min.css" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css"  id="app-stylesheet" />
    <body>

        <!-- Begin page -->
        <div id="wrapper">

            
        <?php include 'c_topbar.php'; ?>

            
            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'c_sidebar.php'; ?>

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Events</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 
                        <div class="row">
                            <div class="col-12">
                                <div class="card-box">
                                    <h4 class="header-title mb-4">List of Joined Event</h4>

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>Title</th>
                                                <th>Location</th>
                                                <th>Date</th>
                                                <th>Amount</th>
                                                <th>Claim</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($getEvent != null) {
                                                    foreach($getEvent as $event){ 
                                                        $checkIfRequest = $control->getTableByCustomWhere($conn, 'records', ' event_id = '. $event['id']);
                                                        $checkIfClaim = $control->getTableByCustomWhere($conn, 'claims', ' event_id = '. $event['id']);
                                                        ?>
                                                <tr>
                                                    <td><img src="../images/<?php echo $event['image'] ?>" width="100"></td>
                                                    <td><?php echo $event['title'] ?></td>
                                                    <td><?php echo $event['location'] ?></td>
                                                    <td><?php echo $event['date'] ?></td>
                                                    <td>RM<?php echo $event['amount'] ?></td>
                                                    <td>
                                                        <?php
                                                        if($checkIfClaim != null){
                                                            if($checkIfClaim['status'] == $control::STATUS_CLAIM_PENDING){
                                                                echo "<span class='badge badge-info'>Pending</span>";
                                                            } else {
                                                                echo "<span class='badge badge-success'>Approve RM". $checkIfClaim['amount'] ."</span>";
                                                            }
                                                        } else {
                                                            echo " No Claim";
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                            if($checkIfClaim != null){
                                                                echo ' - ';
                                                            } else {
                                                                echo '<a class="btn btn-sm btn-success" href="claim.php?id=' . $event["id"] . '">Request To Claim</a>';
                                                            }
                                                        ?>
                                                        
                                                    </td>
                                                </tr>
                                            <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div> <!-- end row -->

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box">
                                    <h4 class="header-title mb-4">List of Rejected Event</h4>

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>Title</th>
                                                <th>Location</th>
                                                <th>Date</th>
                                                <th>Amount</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($getEventRejected != null) {
                                                    foreach($getEventRejected as $event){ ?>
                                                <tr>
                                                    <td><img src="../images/<?php echo $event['image'] ?>" width="100"></td>
                                                    <td><?php echo $event['title'] ?></td>
                                                    <td><?php echo $event['location'] ?></td>
                                                    <td><?php echo $event['date'] ?></td>
                                                    <td>RM<?php echo $event['amount'] ?></td>
                                                    <td></td>
                                                </tr>
                                            <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div> <!-- end row -->
                        
                    </div> <!-- end container-fluid -->

                </div> <!-- end content -->

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2016 - 2019 &copy; Uplon theme by <a href="">Coderthemes</a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

        <script src="assets/libs/jszip/jszip.min.js"></script>
        <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
        <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>

        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Datatables init -->
        <script src="assets/js/pages/datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>
        
    </body>
</html>