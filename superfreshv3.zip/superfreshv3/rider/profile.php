<?php 
include '../controller/controller.php';

if(!isset($_SESSION['user_id'])){
    echo "<script>window.location = '../login.php'</script>";
}

$control = new controller;
$conn = $control->open();

$user = $control->getAuth($conn);

?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'c_head.php'; ?>
    <link href="assets/libs/dropify/dropify.min.css" rel="stylesheet" type="text/css" />
    <body>

        <!-- Begin page -->
        <div id="wrapper">

            
        <?php include 'c_topbar.php'; ?>

            
            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'c_sidebar.php'; ?>

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 
                        <div class="row">
                            <div class="col-lg-8 mb-5 mx-auto">
                                <div class="card shadow">
                                    <div class="card-body pt-0 pt-md-4">
                                        <div class="row">
                                        <div class="col-lg-12">
                                            <button class="float-right btn btn-info btn-sm mx-1" data-toggle="modal" data-target="#exampleModal">Update Profile</button>
                                            <button class="float-right btn btn-danger btn-sm mx-1" data-toggle="modal" data-target="#exampleModal1">Change Password</button>
                                        </div>
                                        </div>
                                        <div class="text-center">
                                        <img src="assets/images/users/<?php echo $user['img'] ?>" class="rounded-circle" width="30%">
                                        <h3>
                                            <?php echo $user['name'] ?><small class="font-weight-light">, <?php echo $user['email'] ?></small>
                                        </h3>
                                        <div class="h5 font-weight-300">
                                            <i class="ni location_pin mr-2"></i>Birthday On: <?php echo date("d M Y", strtotime($user['birthday'])); ?>
                                        </div>
                                        <hr class="my-4">
                                        <em>Success isn't always about greatness. It's about consistency. Consistent hard work gains success. Greatness will come.</em>
                                        <a href="#">Dwayne <b>"The Rock"</b> Jhonson</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                        
                    </div> <!-- end container-fluid -->

                </div> <!-- end content -->

                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form method="post" action="../controller/controller.php?mod=updateProfile" name="editProfile" enctype="multipart/form-data">
                                <div class="modal-body">
                                <div class="card-body">
                                    <h6 class="heading-small text-muted mb-4">Update Profile</h6>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Image</label>
                                            <input type="file" class="dropify" data-height="300" name="imageFile" data-default-file="assets/images/users/<?php echo $user['img'] ?>"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Name</label>
                                            <input type="text" name="name" class="form-control form-control-alternative" placeholder="Name" value="<?php echo $user['name'] ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Email</label>
                                            <input type="text" name="email" class="form-control form-control-alternative" placeholder="Email" value="<?php echo $user['email'] ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Birthday</label>
                                            <input type="date" name="birthday" class="form-control form-control-alternative" placeholder="Birthday" value="<?php echo $user['birthday'] ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr class="my-1" />
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-success">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    </div>

                    <!-- password update modal start -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <form method="post" action="../controller/controller.php?mod=rstpassword">
            <div class="modal-body">
               <div class="card-body">
                  <h6 class="heading-small text-muted mb-4">Update Password</h6>
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="form-group">
                           <label class="form-control-label">Current Password</label>
                           <input type="password" name="old" class="form-control form-control-alternative" placeholder="Current Password" value="" required>
                        </div>
                     </div>
                  </div>
                  <hr class="my-4" />
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="form-group">
                           <label class="form-control-label">New Password</label>
                           <input  id="password"type="password" name="new" class="form-control form-control-alternative" placeholder="New Password" value="" required>
                           <small class="text-danger" id="msgMinPass">Minimum password at least 8 character</small>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="form-group">
                           <label class="form-control-label">Confirm Password</label>
                           <input type="password" name="retype" class="form-control form-control-alternative" placeholder="Confirm Password" value="" required>
                        </div>
                     </div>
                  </div>
               </div>
               <hr class="my-1" />
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               <button type="submit" class="btn btn-danger" name="newpassSubmit" >Confirm Update</button>
            </div>
         </form>
      </div>
   </div>
</div>
<!-- password update modal end -->
                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2016 - 2019 &copy; Uplon theme by <a href="">Coderthemes</a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <script src="assets/libs/dropify/dropify.min.js"></script>

        <script src="assets/js/pages/form-fileuploads.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>
        
    </body>
</html>