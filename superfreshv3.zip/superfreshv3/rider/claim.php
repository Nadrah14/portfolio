<?php 
   include '../controller/controller.php';
   
   if(!isset($_SESSION['user_id'])){
       echo "<script>window.location = '../login.php'</script>";
   }
   
   if(!isset($_GET['id'])){
       echo "<script>window.location='index.php'</script>";
   }
   
   $control = new controller;
   $conn = $control->open();
   
   $user = $control->getAuth($conn);
   $id = $control->valdata($conn, $_GET['id']);
   $getEvent = $control->getTableById($conn, 'events', $id);
   
   ?>
<!DOCTYPE html>
<html lang="en">
   <?php include 'c_head.php'; ?>
   <!-- Table datatable css -->
   <link href="assets/libs/dropify/dropify.min.css" rel="stylesheet" type="text/css" />
   <body>
      <!-- Begin page -->
      <div id="wrapper">
         <?php include 'c_topbar.php'; ?>
         <!-- ========== Left Sidebar Start ========== -->
         <?php include 'c_sidebar.php'; ?>
         <!-- ============================================================== -->
         <!-- Start Page Content here -->
         <!-- ============================================================== -->
         <div class="content-page">
            <div class="content">
               <!-- Start Content-->
               <div class="container-fluid">
                  <!-- start page title -->
                  <div class="row">
                     <div class="col-12">
                        <div class="page-title-box">
                           <h4 class="page-title">Events</h4>
                        </div>
                     </div>
                  </div>
                  <!-- end page title --> 
                  <div class="row">
                     <div class="col-lg-6 mx-auto">
                        <div class="card-box">
                           <div class="row">
                              <div class="col-sm-12 col-lg-12">
                                 <form action="../controller/controller.php?mod=newEvent" method="post" enctype="multipart/form-data">
                                    <div class="card">
                                       <div class="card-body">
                                          <a class="btn btn-danger btn-sm float-right" href="event.php">Back</a>
                                          <h4><?php echo $getEvent['title'] ?></h4>
                                          <h5 class="card-title">Date Time: <?php echo date('d-m-Y', strtotime($getEvent['date'])); ?> <?php echo date('H:i a', strtotime($getEvent['time'])); ?></h5>
                                          <h5 class="card-subtitle text-muted mb-1">Location: <?php echo $getEvent['location'] ?></h5>
                                          <h5 class="card-subtitle text-muted">Amount: RM<?php echo $getEvent['amount'] ?></h5>
                                       </div>
                                       <img class="img-fluid" src="../images/<?php echo $getEvent['image'] ?>" alt="Card image cap">
                                       <div class="card-body">
                                          <h4>Description</h4>
                                          <p class="card-text"><?php echo $getEvent['description'] ?></p>
                                       </div>
                                       <div class="card-body">
                                          <h4>Remakrs</h4>
                                          <p class="card-text"><?php echo $getEvent['remakrs'] ?></p>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                              <!-- end col -->
                           </div>
                           <!-- end row -->
                        </div>
                     </div>
                     <div class="col-lg-6 mx-auto">
                        <div class="card-box">
                           <div class="row">
                              <div class="col-sm-12 col-lg-12">
                                 <form action="../controller/controller.php?mod=addClaim" method="post" >
                                    <div class="card">
                                       <div class="card-body">
                                          <h3>Request Claim</h3>
                                          <div class="form-group">
                                             <label for="">Description</label>
                                             <input type="text" name="description" required class="form-control"/>
                                          </div>
                                          <div class="form-group">
                                             <label for="">Amount</label>
                                             <input type="number" name="amount" step="0.01" required class="form-control"/>
                                          </div>
                                          <div class="form-group">
                                             <input type="hidden" name="event_id" value="<?php echo $id; ?>">
                                            <button class="btn btn-primary" type="submit">Submit</button>
                                          </div>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                              <!-- end col -->
                           </div>
                           <!-- end row -->
                        </div>
                     </div>
                     <!-- end col -->
                  </div>
               </div>
               <!-- end container-fluid -->
            </div>
            <!-- end content -->
            <!-- Footer Start -->
            <footer class="footer">
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-md-12">
                        2016 - 2019 &copy; Uplon theme by <a href="">Coderthemes</a>
                     </div>
                  </div>
               </div>
            </footer>
            <!-- end Footer -->
         </div>
         <!-- ============================================================== -->
         <!-- End Page content -->
         <!-- ============================================================== -->
      </div>
      <!-- END wrapper -->
      <script src="assets/js/vendor.min.js"></script>
      <!-- Datatable plugin js -->
      <script src="assets/libs/dropify/dropify.min.js"></script>
      <script src="assets/js/pages/form-fileuploads.init.js"></script>
      <!-- App js -->
      <script src="assets/js/app.min.js"></script>
   </body>
</html>