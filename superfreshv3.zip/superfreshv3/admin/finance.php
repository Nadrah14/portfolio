<?php 
include '../controller/controller.php';

if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin'){
    echo "<script>window.location = '../login.php'</script>";
}

$control = new controller;
$conn = $control->open();

$user = $control->getAuth($conn);
$getEvent = $control->getListTableName($conn, 'events');
$getClaim = $control->getListTableName($conn, 'claims', ' claims.status = ' . $control::STATUS_CLAIM_PENDING, ', events.title as eventTitle, users.name as userName', ' LEFT JOIN events ON (events.id = claims.event_id) LEFT JOIN users ON (users.id = claims.user_id)');
$getFinance = $control->getListTableName($conn, 'finance');
?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'c_head.php'; ?>
    <!-- Table datatable css -->
    <link href="assets/libs/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        
        <link href="assets/libs/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/select.bootstrap4.min.css" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css"  id="app-stylesheet" />
    <body>

        <!-- Begin page -->
        <div id="wrapper">

            
        <?php include 'c_topbar.php'; ?>

            
            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'c_sidebar.php'; ?>

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Finance</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 
                        <div class="row">
                        <div class="col-lg-6">
                                <div class="card-box">
                                    <h4 class="header-title mb-4">List of Claim (Pending)</h4>

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>From</th>
                                                <th>Event</th>
                                                <th>Description</th>
                                                <th>Amount</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($getClaim != null) {
                                                    foreach($getClaim as $event){ ?>
                                                <tr>
                                                    <td><?php echo $event['userName'] ?></td>
                                                    <td><?php echo $event['eventTitle'] ?></td>
                                                    <td><?php echo $event['detail'] ?></td>
                                                    <td>RM<?php echo $event['amount'] ?></td>
                                                    <td>
                                                        <a href="../controller/controller.php?mod=claimApprove&id=<?php echo $event['id'] ?>" onclick="return confirm('Are you sure to Approve this claim')" class="btn btn-sm btn-success">Approve</a>
                                                        <a href="../controller/controller.php?mod=claimReject&id=<?php echo $event['id'] ?>" onclick="return confirm('Are you sure to Reject this claim')" class="btn btn-sm btn-danger">Reject</a>
                                                    </td>
                                                </tr>
                                            <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <div class="col-lg-6 mx-auto">
                            <div class="card-box">
                                <div class="row">
                                    <div class="col-sm-12">
                                    <div class="card-box">
                                        <p>
                                            <a class="btn btn-success btn-sm float-right mx-1" href="" data-toggle="modal" data-target="#addPendapatan">Pendapatan</a>
                                            <a class="btn btn-danger btn-sm float-right mx-1" href="" data-toggle="modal" data-target="#addPerbelanjaan">Perbelanjaan</a>
                                        </p>
                                        <h4 class="header-title">Kira - kira akaun</h4>
                                       <!--  <p class="sub-header">
                                            Harvester Name: Yoshio Arnold <br>
                                            Harvester Phone: 
                                        </p> -->
                                        <div class=" tablesaw-bar tablesaw-mode-stack"></div>
                                        <table class="tablesaw table mb-0 tablesaw-stack mb-3" data-tablesaw-mode="stack" id="tablesaw-5936">
                                            <thead>
                                                <tr>
                                                <th scope="col" data-tablesaw-sortable-col="" data-tablesaw-priority="persist" width="250">Date</th>
                                                <th scope="col" data-tablesaw-sortable-col="" data-tablesaw-priority="persist" width="250">Detail</th>
                                                <th width="100"></th>
                                                <th scope="col">Pendapatan</th>
                                                <th scope="col">Perbelanjaan</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    if(count($getFinance) > 0){
                                                        $totalPendapatan = 0;
                                                        $totalPerbelanjaan = 0;
                                                        foreach($getFinance as $finance){ 
                                                            if($finance['type'] == 0){ 
                                                                $totalPendapatan += $finance['amount'];
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo $finance['date'] ?></td>
                                                                    <td><?php echo $finance['detail'] ?></td>
                                                                    <td>:</td>
                                                                    <td>RM <?php echo $finance['amount'] ?></td>
                                                                    <td></td>
                                                                </tr>
                                                            <?php } else {
                                                                $totalPerbelanjaan += $finance['amount']; ?>
                                                                <tr>
                                                                    <td><?php echo $finance['date'] ?></td>
                                                                    <td><?php echo $finance['detail'] ?></td>
                                                                    <td>:</td>
                                                                    <td></td>
                                                                    <td>RM <?php echo $finance['amount'] ?></td>
                                                                </tr>
                                                          <?php  } } } ?>
                                                
                                                
                                            </tbody>
                                            <tfoot style="background-color: #f5f5f5;">
                                                <tr>
                                                    <th>Jumlah</th>
                                                    <th></th>
                                                    <th>:</th>
                                                    <th>RM <?php echo (isset($totalPendapatan) ? $totalPendapatan : 0) ?></th>
                                                    <th>RM <?php echo (isset($totalPerbelanjaan) ? $totalPerbelanjaan : 0) ?></th>
                                                </tr>
                                                <tr>
                                                    <th>Jumlah Keuntungan</th>
                                                    <th></th>
                                                    <th>:</th>
                                                    <th></th>
                                                    <th>RM <?php echo(isset($totalPendapatan) ? $totalPendapatan : 0) - (isset($totalPerbelanjaan) ? $totalPerbelanjaan : 0) ?></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                        <!-- <h4 class="header-title float-right">Mandor: Mandor</h4>
                                        <h4 class="header-title">Harvester No : Voluptas est saepe o</h4>
                                        <p class="sub-header">
                                            Harvester Name: Yoshio Arnold <br>
                                            Harvester Phone: 
                                        </p> -->
                                    </div>
                                    </div>
                                    <!-- end col -->
                                </div>
                                <!-- end row -->
                            </div>
                        </div>
                        <!-- end col -->
                        </div>
                        
                    </div> <!-- end container-fluid -->

                </div> <!-- end content -->

                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form method="post" action="../controller/controller.php?mod=updateProfile" name="editProfile">
                                <div class="modal-body">
                                <div class="card-body">
                                    <h6 class="heading-small text-muted mb-4">Update Profile</h6>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Name</label>
                                            <input type="text" name="name" class="form-control form-control-alternative" placeholder="Name" value="<?php echo $user['name'] ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Email</label>
                                            <input type="text" name="email" class="form-control form-control-alternative" placeholder="Email" value="<?php echo $user['email'] ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Birthday</label>
                                            <input type="date" name="birthday" class="form-control form-control-alternative" placeholder="Birthday" value="<?php echo $user['birthday'] ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr class="my-1" />
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-success">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    </div>

                    <div class="modal fade" id="addPendapatan" tabindex="-1" role="dialog" aria-labelledby="addPendapatanLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form method="post" action="../controller/controller.php?mod=addPendapatan" enctype="multipart/form-data">
                            <div class="modal-body">
                                <div class="card-body">
                                    <h6 class="heading-small text-muted mb-4">Pendapatan</h6>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Detail</label>
                                            <input type="text" name="detail" class="form-control form-control-alternative" placeholder="Detail" autocomplete="off" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Jumlah</label>
                                            <input type="number" step="0.01" name="jumlah" class="form-control form-control-alternative" placeholder="Jumlah" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr class="my-1" />
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Hantar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="addPerbelanjaan" tabindex="-1" role="dialog" aria-labelledby="addPerbelanjaanLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form method="post" action="../controller/controller.php?mod=addPerbelanjaan" enctype="multipart/form-data">
                            <div class="modal-body">
                                <div class="card-body">
                                    <h6 class="heading-small text-muted mb-4">Perbelanjaan</h6>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Detail</label>
                                            <input type="text" name="detail" class="form-control form-control-alternative" placeholder="Detail" autocomplete="off" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Jumlah</label>
                                            <input type="number" step="0.01" name="jumlah" class="form-control form-control-alternative" placeholder="Jumlah" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr class="my-1" />
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Hantar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
                

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2016 - 2019 &copy; Uplon theme by <a href="">Coderthemes</a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

        <script src="assets/libs/jszip/jszip.min.js"></script>
        <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
        <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>

        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Datatables init -->
        <script src="assets/js/pages/datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>
        
    </body>
</html>