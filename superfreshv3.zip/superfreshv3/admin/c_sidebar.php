<div class="left-side-menu">

    <div class="slimscroll-menu">

        <!--- Sidemenu -->
        <div id="sidebar-menu">

            <ul class="metismenu" id="side-menu">

                <li class="menu-title">Navigation</li>

                <li>
                    <a href="index.php">
                        <i class="mdi mdi-view-dashboard"></i>
                        <span> Dashboard </span>
                    </a>
                </li>

                <li>
                    <a href="product.php">
                        <i class="mdi mdi-calendar-month"></i>
                        <span> Product </span>
                    </a>
                </li>

                <li>
                    <a href="order.php">
                        <i class="mdi mdi-calendar-month"></i>
                        <span> Order </span>
                    </a>
                </li>
                
            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End -->