<?php 
include '../controller/controller.php';

if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin'){
    echo "<script>window.location = '../login.php'</script>";
}

$control = new controller;
$conn = $control->open();

$user = $control->getAuth($conn);
// $listBirthday = $control->listBirthday($conn);

$getOrderPending = $control->getListTableName($conn, 'orders', ' status = 0 GROUP BY order_num', ', sum(amount) as total');
$getRider = $control->getListTableName($conn, 'users', ' role = "rider"');


$totalOrder = $control->getCount($conn, 'orders');

$totalOrderPending = $control->getCount($conn, 'orders', ' WHERE status = 0');
$totalOrderOFD = $control->getCount($conn, 'orders', ' WHERE status = 1');
$totalOrderComplete = $control->getCount($conn, 'orders', ' WHERE status = 2');
$totalProduct = $control->getCount($conn, 'products');
// $totalPendingEvent = $control->getCount($conn, 'records', 'WHERE status = ' . $control::STATUS_RQT_PENDING . ' AND user_id = ' . $user['id']);
// $totalRejectEvent = $control->getCount($conn, 'records', 'WHERE status = ' . $control::STATUS_RQT_REJECT . ' AND user_id = ' . $user['id']);

?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'c_head.php'; ?>
    <body>

        <!-- Begin page -->
        <div id="wrapper">

            
        <?php include 'c_topbar.php'; ?>

            
            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'c_sidebar.php'; ?>

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-layers float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Total Order</h6>
                                    <h3 class="my-3" data-plugin="counterup"><?php echo count($totalOrder); ?></h3>
                                    <span class="badge badge-success mr-1"> -
                                </div>
                            </div>

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-chart float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Total Product</h6>
                                    <h3 class="my-3"><span data-plugin="counterup"><?php echo $totalProduct['total'] ?></span></h3>
                                    <span class="badge badge-pink mr-1">-
                                </div>
                            </div>

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-paypal float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Order Out Of Delivery</h6>
                                    <h3 class="my-3"><span data-plugin="counterup"><?php echo $totalOrderOFD['total'] ?></span></h3>
                                    <span class="badge badge-danger mr-1"> -
                                </div>
                            </div>

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box tilebox-one">
                                    <i class="icon-rocket float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Order Completed</h6>
                                    <h3 class="my-3" data-plugin="counterup"><?php echo $totalOrderComplete['total'] ?></h3>
                                    <span class="badge badge-warning mr-1"> -
                                </div>
                            </div>
                        </div>
                        <!-- end row -->


                        <div class="row">
                        <div class="col-xl-12">
                                <div class="card-box">

                                    <h4 class="header-title mb-3">Pending Order</h4>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-nowrap mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Order Number</th>
                                                    <th>Item</th>
                                                    <th>Total Amount</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php if($getOrderPending != null) {
                                                foreach($getOrderPending as $order){  
                                                    ?>
                                                <tr>
                                                    <td align="center" ><?php echo $order['order_num'] ?></td>
                                                    <td >
                                                    <ul>
                                                    <?php 
                                                        $getList = $control->getListTableName($conn, 'orders', ' order_num = ' . $order['order_num'], ', products.*', 'LEFT JOIN products ON (products.id = orders.product_id)');
                                                        if($getList != null){
                                                            foreach($getList as $list){
                                                                echo "<li>". $list['product_title'] ." x ". $list['quantity'] ."</li>";
                                                            }
                                                        }
                                                    ?></ul></td>
                                                    <td >RM<?php echo number_format($order['total'], 2) ?></td>
                                                    <td ><?php if($order['status'] == 0) { echo 'Pending'; } else if($order['status'] == 1) { echo 'Out Of Delivery'; } else { echo 'Complete';} ?></td>
                                                </tr>
                                            <?php } } else { ?>
                                                <tr>
                                                    <td colspan="6">No Event Found</td>
                                                </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div><!-- end col-->
                            </div>
                            <!-- end row -->
                            <div class="row">
                                <div class="col-md-12">
                                        <div class="card-box">
                                            <a class="btn btn-success btn-sm float-right" href="" data-toggle="modal" data-target="#addAGM">Add Rider</a>
                                            <h4 class="header-title mb-3">List of Rider</h4>

                                            <div class="table-responsive">
                                        <table class="table table-bordered table-nowrap mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>No Tel</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php if($getRider != null) {
                                                foreach($getRider as $agm){ ?>
                                                <tr>
                                                    <td><?php echo $agm['name'] ?></td>
                                                    <td><?php echo $agm['email'] ?></td>
                                                    <td><?php echo $agm['notel'] ?></td>
                                                    <td>
                                                        <a href="../controller/controller.php?mod=deleteRider&id=<?php echo $agm['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
                                                    </td>
                                                </tr>
                                            <?php } } else { ?>
                                                <tr>
                                                    <td colspan="5">No Agm Notice Found</td>
                                                </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>

                                        </div>
                                    </div>
                            </div>
                        
                    </div> <!-- end container-fluid -->

                </div> <!-- end content -->

                

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2016 - 2019 &copy; Uplon theme by <a href="">Coderthemes</a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <div class="modal fade" id="addAGM" tabindex="-1" role="dialog" aria-labelledby="addAGMLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form method="post" action="../controller/controller.php?mod=addRider">
                            <div class="modal-body">
                                <div class="card-body">
                                    <h6 class="heading-small text-muted mb-4">New Rider</h6>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Name</label>
                                            <input type="text" name="name" class="form-control form-control-alternative" placeholder="Name" autocomplete="off" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Notel</label>
                                            <input type="text" name="notel" class="form-control form-control-alternative" placeholder="notel" autocomplete="off" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Email</label>
                                            <input type="email" name="email" class="form-control form-control-alternative" placeholder="email" autocomplete="off" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                            <label class="form-control-label">Password</label>
                                            <input type="password" name="passwprd" class="form-control form-control-alternative" placeholder="password" autocomplete="off" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr class="my-1" />
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Create</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!--Morris Chart-->
        <script src="assets/libs/morris-js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>

        <!-- Dashboard init js-->
        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>
        
    </body>
</html>