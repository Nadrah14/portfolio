<?php 
   include '../controller/controller.php';
   
   if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin'){
      echo "<script>window.location = '../login.php'</script>";
  }
   
 if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin'){
    echo "<script>window.location = '../login.php'</script>";
}
   
   $control = new controller;
   $conn = $control->open();
   
   $user = $control->getAuth($conn);
   $id = $control->valdata($conn, $_GET['id']);
   $getEvent = $control->getTableById($conn, 'events', $id);
   $getRecordsPending = $control->getListTableName($conn, 'records', ' records.event_id = ' . $id . ' AND records.status = ' . $control::STATUS_RQT_PENDING, ', users.img as img, users.name as name, users.email as email', ' LEFT JOIN events ON (events.id = records.event_id) LEFT JOIN users ON (records.user_id = users.id)');
   $getRecordsApprove = $control->getListTableName($conn, 'records', ' records.event_id = ' . $id . ' AND records.status = ' . $control::STATUS_RQT_ACCEPT, ', users.img as img, users.name as name, users.email as email', ' LEFT JOIN events ON (events.id = records.event_id) LEFT JOIN users ON (records.user_id = users.id)');
   $getRecordsReject = $control->getListTableName($conn, 'records', ' records.event_id = ' . $id . ' AND records.status = ' . $control::STATUS_RQT_REJECT, ', users.img as img, users.name as name, users.email as email', ' LEFT JOIN events ON (events.id = records.event_id) LEFT JOIN users ON (records.user_id = users.id)');
   ?>
<!DOCTYPE html>
<html lang="en">
   <?php include 'c_head.php'; ?>
   <!-- Table datatable css -->
   <link href="assets/libs/dropify/dropify.min.css" rel="stylesheet" type="text/css" />
   <body>
      <!-- Begin page -->
      <div id="wrapper">
         <?php include 'c_topbar.php'; ?>
         <!-- ========== Left Sidebar Start ========== -->
         <?php include 'c_sidebar.php'; ?>
         <!-- ============================================================== -->
         <!-- Start Page Content here -->
         <!-- ============================================================== -->
         <div class="content-page">
            <div class="content">
               <!-- Start Content-->
               <div class="container-fluid">
                  <!-- start page title -->
                  <div class="row">
                     <div class="col-12">
                        <div class="page-title-box">
                           <h4 class="page-title">Events</h4>
                        </div>
                     </div>
                  </div>
                  <!-- end page title --> 
                  <div class="row">
                     <div class="col-lg-4 mx-auto">
                        <div class="card-box">
                           <div class="row">
                              <div class="col-sm-12 col-lg-12">
                                 <form action="../controller/controller.php?mod=newEvent" method="post" enctype="multipart/form-data">
                                    <div class="card">
                                       <div class="card-body">
                                          <a class="btn btn-danger btn-sm float-right" href="event.php">Back</a>
                                          <h4><?php echo $getEvent['title'] ?></h4>
                                          <h5 class="card-title">Date Time: <?php echo date('d-m-Y', strtotime($getEvent['date'])); ?> <?php echo date('H:i a', strtotime($getEvent['time'])); ?></h5>
                                          <h5 class="card-subtitle text-muted mb-1">Location: <?php echo $getEvent['location'] ?></h5>
                                          <h5 class="card-subtitle text-muted">Amount: RM<?php echo $getEvent['amount'] ?></h5>
                                       </div>
                                       <img class="img-fluid" src="../images/<?php echo $getEvent['image'] ?>" alt="Card image cap">
                                       <div class="card-body">
                                          <h4>Description</h4>
                                          <p class="card-text"><?php echo $getEvent['description'] ?></p>
                                       </div>
                                       <div class="card-body">
                                          <h4>Remakrs</h4>
                                          <p class="card-text"><?php echo $getEvent['remakrs'] ?></p>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                              <!-- end col -->
                           </div>
                           <!-- end row -->
                        </div>
                     </div>
                     <div class="col-lg-8 mx-auto">
                     <div class="card-box">
                                    <h4 class="header-title mb-4">List of Event (Pending)</h4>

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>name</th>
                                                <th>Email</th>
                                                <th>Receipt</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($getRecordsPending != null) {
                                                    foreach($getRecordsPending as $recordPending){  ?>
                                                <tr>
                                                   <td><img src="assets/images/users/<?php echo $recordPending['img'] ?>" width="100"></td>
                                                    <td><?php echo $recordPending['name'] ?></td>
                                                    <td><?php echo $recordPending['email'] ?></td>
                                                    <td><a href="../receipt/<?php echo $recordPending['document'] ?>" download="<?php echo $recordApprove['document'] ?>" class="btn btn-sm btn-info">Download</a></td>
                                                    <td>
                                                        <a class="btn btn-success btn-sm mx-1" onclick="return confirm('Are you sure to accept this member ?')" href="../controller/controller.php?mod=acceptEvent&idEvent=<?php echo $getEvent['id'] ?>&id=<?php echo $recordPending['id'] ?>" >Approve</a>
                                                        <a class="btn btn-danger btn-sm mx-1" onclick="return confirm('Are you sure to reject this member ?')" href="../controller/controller.php?mod=rejectEvent&idEvent=<?php echo $getEvent['id'] ?>&id=<?php echo $recordPending['id'] ?>" >Reject</a>
                                                    </td>
                                                </tr>
                                            <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="card-box">
                                    <h4 class="header-title mb-4">List of Event (Approve)</h4>

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>name</th>
                                                <th>Email</th>
                                                <th>Receipt</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($getRecordsApprove != null) {
                                                    foreach($getRecordsApprove as $record){  ?>
                                                <tr>
                                                   <td><img src="assets/images/users/<?php echo $record['img'] ?>" width="100"></td>
                                                    <td><?php echo $record['name'] ?></td>
                                                    <td><?php echo $record['email'] ?></td>
                                                    <td><a href="../receipt/<?php echo $record['document'] ?>" download="<?php echo $record['document'] ?>" class="btn btn-sm btn-info">Download</a></td>
                                                    
                                                </tr>
                                            <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="card-box">
                                    <h4 class="header-title mb-4">List of Event (Reject)</h4>

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>name</th>
                                                <th>Email</th>
                                                <th>Receipt</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($getRecordsReject != null) {
                                                    foreach($getRecordsReject as $reject){  ?>
                                                <tr>
                                                   <td><img src="assets/images/users/<?php echo $reject['img'] ?>" width="100"></td>
                                                    <td><?php echo $reject['name'] ?></td>
                                                    <td><?php echo $reject['email'] ?></td>
                                                    <td><a href="../receipt/<?php echo $reject['document'] ?>" download="<?php echo $reject['document'] ?>" class="btn btn-sm btn-info">Download</a></td>
                                                    
                                                </tr>
                                            <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>
                     </div>
                     <!-- end col -->
                  </div>
               </div>
               <!-- end container-fluid -->
            </div>
            <!-- end content -->
            <!-- Footer Start -->
            <footer class="footer">
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-md-12">
                        2016 - 2019 &copy; Uplon theme by <a href="">Coderthemes</a>
                     </div>
                  </div>
               </div>
            </footer>
            <!-- end Footer -->
         </div>
         <!-- ============================================================== -->
         <!-- End Page content -->
         <!-- ============================================================== -->
      </div>
      <!-- END wrapper -->
      <script src="assets/js/vendor.min.js"></script>
      <!-- Datatable plugin js -->
      <script src="assets/libs/dropify/dropify.min.js"></script>
      <script src="assets/js/pages/form-fileuploads.init.js"></script>
      <!-- App js -->
      <script src="assets/js/app.min.js"></script>
   </body>
</html>