-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table superfreshv3.brands
DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `brand_id` int(100) NOT NULL AUTO_INCREMENT,
  `brand_title` text NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table superfreshv3.brands: ~0 rows (approximately)
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
REPLACE INTO `brands` (`brand_id`, `brand_title`) VALUES
	(1, 'Grocery');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;

-- Dumping structure for table superfreshv3.cart
DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL,
  `total` float DEFAULT '0',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `p_id` (`p_id`),
  CONSTRAINT `FK_cart_products` FOREIGN KEY (`p_id`) REFERENCES `products` (`id`),
  CONSTRAINT `FK_cart_user_info` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

-- Dumping data for table superfreshv3.cart: ~4 rows (approximately)
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
REPLACE INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`, `total`, `status`) VALUES
	(27, 1, '127.0.0.1', 29, 1, 14.71, 0);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;

-- Dumping structure for table superfreshv3.categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(100) NOT NULL AUTO_INCREMENT,
  `cat_title` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table superfreshv3.categories: ~7 rows (approximately)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
REPLACE INTO `categories` (`cat_id`, `cat_title`) VALUES
	(1, 'Frozen'),
	(2, 'Fresh'),
	(3, 'Grocery'),
	(4, 'Fruit'),
	(5, 'Vegetable'),
	(6, 'Herbs'),
	(7, 'Others');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Dumping structure for table superfreshv3.orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `rider_id` int(11) DEFAULT NULL,
  `order_num` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `cart_id` (`product_id`),
  KEY `rider_id` (`rider_id`),
  CONSTRAINT `FK__user_info` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`),
  CONSTRAINT `FK__users` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_orders_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table superfreshv3.orders: ~0 rows (approximately)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
REPLACE INTO `orders` (`id`, `user_id`, `product_id`, `rider_id`, `order_num`, `quantity`, `amount`, `status`) VALUES
	(2, 29, 1, NULL, '4939004223', 1, 123, 0),
	(3, 29, 1, NULL, '9323010901', 1, 14.71, 0),
	(4, 29, 10, NULL, '9323010901', 1, 12.43, 0),
	(5, 29, 1, NULL, '2538013536', 1, 14.71, 0);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Dumping structure for table superfreshv3.products
DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` float NOT NULL DEFAULT '0',
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_cat` (`product_cat`),
  KEY `product_brand` (`product_brand`),
  CONSTRAINT `FK_products_brands` FOREIGN KEY (`product_brand`) REFERENCES `brands` (`brand_id`),
  CONSTRAINT `FK_products_categories` FOREIGN KEY (`product_cat`) REFERENCES `categories` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

-- Dumping data for table superfreshv3.products: ~10 rows (approximately)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
REPLACE INTO `products` (`id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
	(1, 1, 1, 'Whole Fresh Chicken with Head & Feet', 14.71, 'This product is certified halal by Jakim. Suppliers’ halal certification for local chicken/beef are from JAKIM/JAIN whilst imported beef/buffalo/lamb/mutton from Islamic bodies recognized by JAKIM in Australia, New Zealand, India', 'ayam.png', 'This product is certified halal by Jakim. Suppliers’ halal certification for local chicken/beef are from JAKIM/JAIN whilst imported beef/buffalo/lamb/mutton from Islamic bodies recognized by JAKIM in Australia, New Zealand, India'),
	(10, 2, 1, 'Eat Fresh Green Spinach (Bayam Hijau)', 1.31, 'Eat Fresh Green Spinach (Bayam Hijau)', 'ShotType1_540x540.jpg', 'Eat Fresh Green Spinach (Bayam Hijau)'),
	(16, 3, 1, 'Jasmine Super Special Tempatan 5% Rice 10kg', 23.99, 'Jasmine - money-back guarantee, Freshly packed in the rice mill, Awarded Superbrands Asia Top Performer, The BrandLaureate - The SMEs Best Brands Asia Pacific, The Grammy Awards for Branding 2007-2018, Superbrands Malaysia\'s Choice 2002-2016, Trusted Brand Platinum Malaysia 2004-2018, Halal - Malaysia', 'beras.jpg', 'Jasmine - money-back guarantee, Freshly packed in the rice mill, Awarded Superbrands Asia Top Performer, The BrandLaureate - The SMEs Best Brands Asia Pacific, The Grammy Awards for Branding 2007-2018, Superbrands Malaysia\'s Choice 2002-2016, Trusted Brand Platinum Malaysia 2004-2018, Halal - Malaysia'),
	(22, 4, 1, 'Eat Fresh Pisang Cavendish', 3.64, 'Eat Fresh Pisang Cavendish', 'pisang.jpg', 'Eat Fresh Pisang Cavendish'),
	(32, 5, 1, 'Eat Fresh Sawi Muda Pak Choy 200g', 2.99, 'Eat Fresh Sawi Muda Pak Choy 200g', 'sawi.jpg', 'Eat Fresh Sawi Muda Pak Choy 200g'),
	(33, 6, 1, 'Mixed Herbs Perfect From London 14g', 4.95, 'Perfectly Balanced And Versatile, Perfect For Pasta Sauces, Suitable For Vegetarians', 'herbs.jpg', 'Perfectly Balanced And Versatile, Perfect For Pasta Sauces, Suitable For Vegetarians'),
	(72, 7, 1, 'Nestle Cerelac Wheat & Honey Infant Cereal From 6 Months 500g', 11.89, 'Nestlé Cerelac Wheat & Honey Infant Cereal From 6 Months 500g', 'others.png', 'Nestlé Cerelac Wheat & Honey Infant Cereal From 6 Months 500g'),
	(82, 1, 1, 'ramly burger', 16, 'ramly burger', '1601188411_burgerdagingramly.png', 'sdfsdfg'),
	(83, 7, 1, 'Nestle Cerelac Wheat & Honey Infant Cereal From 6 Months 500g', 11.89, 'Nestlé Cerelac Wheat & Honey Infant Cereal From 6 Months 500g', 'others.png', 'Nestlé Cerelac Wheat & Honey Infant Cereal From 6 Months 500g'),
	(84, 7, 1, 'Munchy\'s Oat Krunch Dark Chocolate Crackers 16 Packs 416g', 7.95, 'Munchy\'s Oat Krunch Dark Chocolate Crackers 16 Packs 416g', '1601212150_munchy.jpg', 'Oat Krunch Dark Chocolate');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dumping structure for table superfreshv3.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `notel` varchar(200) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table superfreshv3.users: ~2 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`id`, `name`, `email`, `password`, `notel`, `role`) VALUES
	(1, 'Admin', 'admin@gmail.com', 'admin', '1232352345', 'admin'),
	(3, 'Denton Levy', 'xinajozu@mailinator.com', 'admin', 'In tempora adipisci', 'rider');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table superfreshv3.user_info
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

-- Dumping data for table superfreshv3.user_info: ~3 rows (approximately)
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
REPLACE INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
	(28, 'Hall Meadows', 'Katell Hendrix', 'qecojiqut@mailinator.com', 'Pa$$w0rd!', '0123456789', '72 South Clarendon Freeway', 'Elit quod necessita'),
	(29, 'Cooper Petty', 'Leah Matthews', 'a@g.com', 'a', 'Aute quidem amet qu', '30 East Clarendon Drive', 'Quam excepturi expli'),
	(30, 'Mariam Drake', 'Leandra Keller', 'nuwax@mailinator.com', 'Pa$$w0rd!', 'Ad et soluta debitis', '77 Rocky Hague Drive', 'Veniam natus aut eu');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
