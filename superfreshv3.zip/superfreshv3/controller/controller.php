<?php
session_start();
$config = new controller();
	class controller{


		function __construct(){
			if (isset($_GET['mod'])) {
				$conn = $this->open();
				$action = $this->valdata($conn, $_GET['mod']);

				switch ($action) {

					//---------------- START BASIC PART ----------------


					case 'deleteRider':
						$this->deleteRider($conn);
						break;

					case 'addRider':
						$this->addRider($conn);
						break;

					case 'checkoutOrder':
						$this->checkoutOrder($conn);
						break;

					case 'newEvent':
						$this->newEvent($conn);
						break;

					case 'login':
						$this->login($conn);
						break;

					case 'register':
						$this->register($conn);
						break;

					case 'updateProfile':
						$this->updateProfile($conn);
						break;

					case 'rstpassword':
						$this->rstpassword($conn);
						break;

					case 'logout':
						$this->logout($conn);
						break;

					
					//---------------- END BASIC PART ----------------
					
				}
			}
		}

		public function checkoutOrder($conn){
			$f_name = $_POST["firstname"];
			$email = $_POST['email'];
			$address = $_POST['address'];
			$city = $_POST['city'];
			$state = $_POST['state'];
			$zip= $_POST['zip'];
			$cardname= $_POST['cardname'];
			$cardnumber= $_POST['cardNumber'];
			$expdate= $_POST['expdate'];
			$cvv= $_POST['cvv'];
			$user_id=$_SESSION["uid"];
			$cardnumberstr=(string)$cardnumber;
			$total_count=$_POST['total_count'];
			$prod_total = $_POST['total_price'];

			$user = $this->getTableByCustomWhere($conn, 'user_info', ' user_id = ' . $user_id);
			$getALlCart = $this->getListTableName($conn, 'cart', ' user_id = ' . $user_id );
			$orderNum = rand(99,9999) . date('His');
			if($getALlCart != null){
				foreach($getALlCart as $cart){
					$sql = "INSERT INTO orders (user_id, product_id, order_num, quantity, amount) VALUES (?,?,?,?,?)";
					$stmt = $conn->prepare($sql);
					$rs = $stmt->execute([$user_id, $cart['p_id'], $orderNum, $cart['qty'], $cart['total']]);

					$sqlUpdate = "DELETE FROM cart WHERE id = ?";
					$stmtUpdate = $conn->prepare($sqlUpdate);
					$rsUpdate = $stmtUpdate->execute([$cart['id']]);
				}


				echo "<script>window.alert('Successfull Checkout')</script>";
				echo "<script>window.location = '../index.php'</script>";
				exit;
			}

			echo "<script>window.alert('Nothing For Checkout')</script>";
			echo "<script>window.location = '../index.php'</script>";
			exit;

		}

		public function deleteRider($conn){
			$id = $this->valdata($conn, $_GET['id']);

			$this->deleteById($conn, 'users', $id);
			echo "<script>window.alert('Rider Berjaya dihapuskan')</script>";
			echo "<script>window.location = '../admin/index.php'</script>";
			exit;
		}

		public function addRider($conn){
			
			$name = $this->valdata($conn, $_POST['name']);
			$email = $this->valdata($conn, $_POST['email']);
			$password = $this->valdata($conn, $_POST['password']);
			$password = md5($password);
			$notel = $this->valdata($conn, $_POST['notel']);

			$sql = "INSERT INTO users (name, email, notel, password, role) values (?,?,?,?, 'rider')";
			$stmt = $conn->prepare($sql);
			$rs = $stmt->execute([$name, $email, $notel, $password]);
			if(!$rs){
				echo "<script>window.alert('Error, Sila cuba sekali lagi')</script>";
				echo "<script>window.location = '../admin/index.php'</script>";
				exit;
			}
			echo "<script>window.alert('Rider Berjaya ditambah')</script>";
			echo "<script>window.location = '../admin/index.php'</script>";
			exit;

		}

        // --------------------------- START BASIC PART ---------------------------

        public function getLoockup($conn, $tableName, $where = null){
			$sql = "SELECT * FROM $tableName" . $where;
	        $stmt = $conn->prepare($sql);
			$stmt->execute();
			
			if ($stmt) {
	        	while($row = $stmt->fetchAll()){
					return $row;
				}
	        } else {
	        	return 0;
	        }
        }
        
        public function getCount($conn, $tableName, $where = null){
			$sql = "SELECT count(id) as total FROM $tableName $where";
	        $stmt = $conn->prepare($sql);
	        $stmt->execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;	
			}
        }
        
        public function getListTableName($conn, $tableName , $query = false, $select = false, $join = false){
			if($query){
				$sql = "SELECT $tableName.* $select FROM $tableName $join WHERE $query";
			} else {
				$sql = "SELECT * FROM $tableName";
			}

			// var_dump($sql); 
			
			// echo "<br>";

	        $stmt = $conn->prepare($sql);
			$stmt->execute();
			
			if ($stmt) {
	        	while($row = $stmt->fetchAll()){
					return $row;
				}
	        } else {
	        	return 0;
	        }
		}
		
		public function deleteById($conn, $tableName, $id){
			$sql = "DELETE FROM $tableName WHERE id=$id";
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			
			return 1;
		}

		public function getTableByCustomWhere($conn, $tableName, $query, $select = null){
			$sql = "SELECT * $select FROM $tableName WHERE $query";
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;	
			}
		}
		
		public function getTableById($conn, $tableName, $id, $query = null){
			$sql = "SELECT * FROM $tableName WHERE id = $id $query";

			var_dump($sql);
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;	
			}
		}
        
		public function getUser($conn, $id){
			$sql = "SELECT * FROM admin WHERE admin_id = :id";
	        $stmt = $conn->prepare($sql);
	        $stmt->bindparam(':id', $id);
	        $stmt->execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;	
			}
		}

		public function updateProfile($conn){
			$user = $this->getAuth($conn);

			$gotFile = 0;
			$fileName = '';
			if($_FILES['imageFile']['name'] != null){
				$target_dir = "../admin/assets/images/users/";
				$fileName = date('His') . basename($_FILES["imageFile"]["name"]);
				$imageFileType = strtolower(pathinfo($fileName,PATHINFO_EXTENSION));

				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
					echo "<script>window.alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.')</script>";
					echo "<script>window.location = '../admin/info.php'</script>";
					exit;
				}

				$gotFile = 1;
			} else {
				$fileName = $user['img'];
			}
			

			$name = $this->valdata($conn, $_POST['name']);
			$email = $this->valdata($conn, $_POST['email']);
			$birthday = $this->valdata($conn, $_POST['birthday']);
			$image = $fileName;

			$stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, birthday = ?, img= ? WHERE id = ?");
			$stmt->execute([$name, $email, $birthday, $image, $user['id']]);
			if($gotFile == 1){
				move_uploaded_file($_FILES["imageFile"]["tmp_name"], $target_dir . $fileName);
			}
			echo "<script>window.alert('Data berjaya dikemaskini')</script>";
			echo "<script>window.location = '../admin/profile.php'</script>";
		}
		
		public function rstpassword($conn){
			if (isset($_POST['newpassSubmit'])) {

				$oldpass = $this->valdata($conn,$_POST['old']);
				$oldpass = md5($oldpass);
				$newpass = $this->valdata($conn,$_POST['new']);
				$retypenewpass = $this->valdata($conn,$_POST['retype']);

				$getUser = $this->getAuth($conn);

				if ($newpass == $retypenewpass) {

					if ($getUser['password'] == $oldpass) {
						try {
							$stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
							$stmt->execute([md5($newpass), $getUser['id']]);
							echo "<script>window.alert('password anda telah ditukar')</script>";
							echo "<script>window.location = '../admin/profile.php'</script>";
						} catch(PDOException $e) {
							echo "<script>window.alert('". (strpos($e->getMessage(), "Duplicate entry")? "":'RALAT: Sila Hubungi pihak admin.') ."')</script>";
							echo "<script>window.location = '../admin/profile.php'</script>";
						}
					} else {
						echo "<script>window.alert('Password lama anda tidak sama, sila cuba lagi')</script>";
						echo "<script>window.location = '../admin/profile.php'</script>";
					}
				} else {
					echo "<script>window.alert('retype password anda tidak sama, sila cuba sekali lagi')</script>";
					echo "<script>window.location = '../admin/profile.php'</script>";
				}
			}
        }
        
        public function getAuth($conn){

			if(isset($_SESSION['user_id'])){
				$id = $_SESSION['user_id'];
				$sql = "SELECT * FROM users WHERE id = :id";
				
				$stmt = $conn->prepare($sql);
				$stmt->bindparam(':id', $id);
				$stmt->execute();
				while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					return $row;	
				}
			} else {
				return 0;
			}
		}

		public function register($conn){

			$name = $this->valdata($conn, $_POST['name']);
			$email = $this->valdata($conn, $_POST['email']);
			$password = $this->valdata($conn, $_POST['password']);
			$password = md5($password);
			$birthday = $this->valdata($conn, $_POST['birthday']);
			$role = 'member';


			$sql = "INSERT INTO users (name, email, birthday, password, role) VALUES (?,?,?,?,?)";
			$stmt = $conn->prepare($sql);
			$rs = $stmt->execute([$name, $email, $birthday, $password, $role]);
			if($rs){
				echo "<script>window.alert('Berjaya didaftarkan. Sila log masuk.')</script>";
				echo "<script>window.location = '../login.php'</script>";
			}
		}

		public function login($conn){
			$email = $this->valdata($conn,$_POST['email']);
			$encrypted = md5($this->valdata($conn,$_POST['password']));

			//for admin
			$sql = "SELECT * FROM users WHERE email = :email AND password = :encrypted";
	        $stmt = $conn->prepare($sql);
	        $stmt->bindparam(':email', $email);
	        $stmt->bindparam(':encrypted', $encrypted);
	        $stmt->execute();
			$user = $stmt->fetch(PDO::FETCH_ASSOC);
			
			if($user){
				$_SESSION['user_id'] = $user['id'];
				$_SESSION['user_role'] = $user['role'];

				if($user['role'] == 'admin'){
					echo "<script>window.alert('Hai ". $user['name'] .", Selamat Datang ke TISSAC')</script>";
					echo "<script>window.location = '../admin/index.php'</script>";
				} else {
					echo "<script>window.alert('Hai ". $user['name'] .", Selamat Datang ke TISSAC')</script>";
					echo "<script>window.location = '../member/index.php'</script>";
				}

			} else {
				echo "<script>window.alert('username atau kata laluan anda salah, sila masukkan yang betul.')</script>";
				echo "<script>window.location = '../index.php'</script>";
			}
		}

		public function valdata($conn, $inputpost) {
			if (is_array($inputpost) && count($inputpost) > 0) {
				foreach ($inputpost as $input) {
					$inputpost[] = trim($input);
					$inputpost[] = stripslashes($input);
					$inputpost[] = htmlspecialchars($input);
				}
				return $inputpost;
			} else {
				$inputpost = trim($inputpost);
				$inputpost = stripslashes($inputpost);
				$inputpost = htmlspecialchars($inputpost);
				return $inputpost;
			}
			
		}

		public function logout($conn){
			session_destroy();
			echo "<script>window.location='../'</script>";
		}

		public function open(){
			date_default_timezone_set("Asia/Kuala_Lumpur");
			$choose = 1;
			$conn = "";
			$production = false;

			if ($production) {
				$servername = "localhost";
				$dbname = "id16021432_tissac";
				$username = "id16021432_tissac_user";
				$password = "?!]37&O0mtbx4*5M";
			} else {
				$servername = "localhost";
				$dbname = "superfreshv3";
				$username = "root";
				$password = "root";
			}

			try {
			    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
			    // set the PDO error mode to exception
			    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    return $conn;
			}
			catch(PDOException $e)
			    {
			    echo "Connection failed: " . $e->getMessage();
			}
		}
		// --------------------------- END BASIC PART ---------------------------

		
	}
?>